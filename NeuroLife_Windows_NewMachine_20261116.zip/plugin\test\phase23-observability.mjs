/**
 * Phase 2.3 可观测性验收测试
 *  - facts.trace 状态机（NONE 推进；null/空白/解析失败/写库失败不推进）
 *  - usage 分类（facts 独立记账、other 不被污染；路由不变）
 *  - 并发 record 不丢更新
 *  - build hash 基于实际文件内容
 *  - trace 环形上限、不含正文
 *
 * 全部临时库 + 假模型。
 */
import { mkdtempSync, writeFileSync, copyFileSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const lib = new URL('../lib/', import.meta.url).href;
const { openDatabase, getKv, setKv } = await import(lib + 'db.js');
const { runFactsTick, ensureFacts } = await import(lib + 'facts.js');
const { computeBuildId, appendTrace, factsTraceEntry } = await import(lib + 'observability.js');
const { LlmRouter, FEATURES, ACCOUNTING_ONLY } = await import(lib + 'llm.js');
const goals = await import(lib + 'goals.js');

const dir = mkdtempSync(join(tmpdir(), 'obs-'));
const db = openDatabase(join(dir, 'soul.db'));
ensureFacts(db);

let pass = 0;
let fail = 0;
function check(name, ok, detail = '') {
	if (ok) { pass++; console.log(`PASS  ${name}${detail ? '  — ' + detail : ''}`); }
	else { fail++; console.log(`FAIL  ${name}${detail ? '  — ' + detail : ''}`); }
}

const mk = (id, content, at) => ({ id, content, self: false, at });
const four = [
	mk(1, '他说今天风很大，出门记得把外套扣好别着凉', 1000),
	mk(2, '他说中午想吃楼下那家牛肉面，加个蛋', 1100),
	mk(3, '他说明天要早起赶七点的车，六点就得出门', 1200),
	mk(4, '他说最近睡得不太好，想早点躺下试试', 1300)
];

// ── 1. 状态机 ──
setKv(db, 'facts.lastAt', 0);
let r = await runFactsTick({ db, sample: () => four.slice(0, 3), now: 2000, callLlm: async () => '他喜欢面' });
check('1a 不足 4 条 → insufficient 不推进', r.status === 'insufficient' && r.advanced === false, r.status);

setKv(db, 'facts.lastAt', 0);
r = await runFactsTick({ db, sample: () => four, now: 2000, callLlm: async () => 'NONE' });
check('1b NONE → 推进', r.status === 'none' && r.advanced === true && Number(getKv(db, 'facts.lastAt', 0)) === 1300, JSON.stringify({ status: r.status, wm: getKv(db, 'facts.lastAt', 0) }));

setKv(db, 'facts.lastAt', 0);
r = await runFactsTick({ db, sample: () => four, now: 2000, callLlm: async () => '' });
check('1c 空白 → 不推进', r.status === 'empty' && r.advanced === false);

setKv(db, 'facts.lastAt', 0);
r = await runFactsTick({ db, sample: () => four, now: 2000, callLlm: async () => '好的，我来看看。' });
check('1d 解析失败 → 不推进', r.status === 'parse_fail' && r.advanced === false, r.status);

setKv(db, 'facts.lastAt', 0);
r = await runFactsTick({ db, sample: () => four, now: 2000, callLlm: async () => null });
check('1e null → 不推进', r.status === 'null' && r.advanced === false);

setKv(db, 'facts.lastAt', 0);
r = await runFactsTick({ db, sample: () => four, now: 2000, callLlm: async () => '他吃不惯香菜' });
const factRows = db.prepare('select count(*) c from facts').get().c;
check('1f 有事实 → 落库并推进', r.status === 'facts' && r.added.length === 1 && factRows >= 1, JSON.stringify({ status: r.status, added: r.added.length }));

// ── 1g. 数据库写入失败 → 不推进 ──
const badDb = {
	prepare(sql) {
		if (/INSERT INTO facts/i.test(sql)) return { run() { throw new Error('disk full'); } };
		return db.prepare(sql);
	}
};
setKv(db, 'facts.lastAt', 0);
const beforeWm = Number(getKv(db, 'facts.lastAt', 0));
const rBad = await runFactsTick({ db: badDb, sample: () => four, now: 2000, callLlm: async () => '他吃不惯香菜' });
check('1g 写库失败 → error 且不推进', rBad.status === 'error' && Number(getKv(db, 'facts.lastAt', 0)) === beforeWm, JSON.stringify({ status: rBad.status, wm: getKv(db, 'facts.lastAt', 0) }));

// ── 1h. 太短的 transcript ──
const tiny = [mk(1, '嗯', 1000), mk(2, '哦', 1100), mk(3, '好', 1200), mk(4, '行', 1300)];
setKv(db, 'facts.lastAt', 0);
const rTiny = await runFactsTick({ db, sample: () => tiny, now: 2000, callLlm: async () => '他喜欢面' });
check('1h 太短 → short 不推进', rTiny.status === 'short' && rTiny.advanced === false, rTiny.status);

// ── 2. usage 分类 ──
check('2a FEATURES 不含 facts（路由不变）', !FEATURES.some(([id]) => id === 'facts'));
check('2b ACCOUNTING_ONLY 含 facts', ACCOUNTING_ONLY.some(([id]) => id === 'facts'));

function fakeCtx() {
	const fakeLlm = {
		listProviders: () => [{ id: 'deepseek-official', name: 'DeepSeek' }, { id: 'deepseek-account', name: 'DeepSeek Account' }],
		listModels: async (p) => (p === 'deepseek-official' ? [] : [{ id: 'deepseek-flash', name: 'Flash' }]),
		stream: async function* () {
			yield { type: 'text-delta', text: '他喜欢面' };
			yield { type: 'finish', reason: { kind: 'stop' } };
		}
	};
	return {
		llm: fakeLlm,
		get(n) {
			if (n === 'llm') return fakeLlm;
			if (n === 'agentDefaultModel') return { currentSelection: () => ({ provider: 'deepseek-official', model: 'deepseek-flash' }) };
			return null;
		}
	};
}
const router = new LlmRouter({ ctx: fakeCtx(), db, getConfig: () => ({}), log: () => {} });
const before = JSON.parse(JSON.stringify(getKv(db, 'usage.2026-11-12', {}) ?? {}));
await router.call('hi', { feature: 'facts', maxTokens: 10 });
await router.call('hi', { feature: 'madeup-feature', maxTokens: 10 });
const usage = getKv(db, 'usage.2026-11-12', {});
check('2c facts 独立记账', Number(usage.facts?.calls ?? 0) >= 1, JSON.stringify(usage.facts?.calls));
check('2d 未知功能仍落 other', Number(usage.other?.calls ?? 0) >= 1, JSON.stringify(usage.other?.calls));

// ── 3. 并发 record 不丢 ──
const beforeCalls = Number(getKv(db, 'usage.2026-11-12', {}).facts?.calls ?? 0);
await Promise.all(Array.from({ length: 100 }, () => router.call('x', { feature: 'facts', maxTokens: 10 })));
const afterCalls = Number(getKv(db, 'usage.2026-11-12', {}).facts?.calls ?? 0);
check('3 并发 100 次 record 不丢', afterCalls - beforeCalls === 100, `${beforeCalls} → ${afterCalls}`);

// ── 4. build hash ──
const srcDir = new URL('../lib/', import.meta.url);
const files = ['index.js', 'facts.js', 'llm.js'].map((f) => new URL(f, srcDir));
const tmpFiles = files.map((u, i) => {
	const dst = join(dir, `copy-${i}.js`);
	copyFileSync(u, dst);
	return dst;
});
const h1 = computeBuildId(tmpFiles, 'v1');
const h2 = computeBuildId(tmpFiles, 'v1');
check('4a 同内容 hash 稳定', h1 === h2 && h1.startsWith('b'), h1);
writeFileSync(tmpFiles[1], readFileSync(tmpFiles[1], 'utf8') + '\n// changed\n');
const h3 = computeBuildId(tmpFiles, 'v1');
check('4b 内容变化 hash 变化（不是按目录/时间）', h3 !== h1, `${h1} → ${h3}`);

// ── 5. trace 环形与脱敏 ──
for (let i = 0; i < 25; i++) appendTrace(db, 'test.trace', { i }, { limit: 20 });
const tr = getKv(db, 'test.trace', []);
check('5a trace 环形保留 20', Array.isArray(tr) && tr.length === 20 && tr[0].i === 5, `len=${tr.length} first=${tr[0]?.i}`);
const entry = factsTraceEntry({
	at: 1, build: 'b123', meta: { provider: 'deepseek-account', model: 'deepseek-flash', ok: true },
	status: 'none', rows: 4, theirs: 4, chunk: 4, transcriptLen: 100, added: 0,
	watermarkBefore: 1, watermarkAfter: 2, durationMs: 5
});
const entryText = JSON.stringify(entry);
check('5b trace 不含正文/密钥字段', !/content|prompt|apiKey|transcriptText/i.test(entryText) && entry.model === 'deepseek-flash');
check('5c trace 状态与水位齐全', entry.status === 'none' && entry.watermarkBefore === 1 && entry.watermarkAfter === 2);

console.log(`\n结果：通过 ${pass} / ${pass + fail}`);
db.close();
process.exit(fail === 0 ? 0 : 1);
