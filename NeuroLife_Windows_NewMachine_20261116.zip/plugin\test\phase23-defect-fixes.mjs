/**
 * Phase 2.3 缺陷修复验收测试
 *  1) backfill 记忆不再绕过去重（静态检查 + insertMemory 行为）
 *  2) facts 水位：不足 4 条不推进；够 4 条才抽取并推进
 *  3) goals 额度：脏计数会挡住推进；清零后恢复
 *
 * 全部使用临时数据库（openDatabase(path)）。
 */
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const lib = new URL('../lib/', import.meta.url).href;
const { openDatabase, getKv, setKv } = await import(lib + 'db.js');
const { insertMemory } = await import(lib + 'soul-memory.js');
const { runFactsTick, ensureFacts } = await import(lib + 'facts.js');
const goals = await import(lib + 'goals.js');

const dir = mkdtempSync(join(tmpdir(), 'phase23-'));
const db = openDatabase(join(dir, 'soul.db'));

let pass = 0;
let fail = 0;
function check(name, ok, detail = '') {
	if (ok) { pass++; console.log(`PASS  ${name}${detail ? '  — ' + detail : ''}`); }
	else { fail++; console.log(`FAIL  ${name}${detail ? '  — ' + detail : ''}`); }
}

// ── 1. backfill 记忆不再绕过去重 ──
const src = readFileSync(new URL('../lib/index.js', import.meta.url), 'utf8');
const block = src.slice(src.indexOf('memorizeUnanswered(person, m)'), src.indexOf('memorizeUnanswered(person, m)') + 900);
check('1a memorizeUnanswered 走 insertMemory', /insertMemory\(db, worker/.test(block));
check('1b 不再直接 INSERT INTO memory', !/INSERT INTO memory/.test(block));

const workerStub = { enqueueRealtime: () => {} };
const m1 = { ownerId: 'user:master', channel: 'qq-private', channelId: 'private:1', kind: 'event', content: '同一句话', importance: 1, emotion: 0 };
const a = insertMemory(db, workerStub, m1, 1000);
const b = insertMemory(db, workerStub, m1, 2000);
check('1c 同内容只写一条', a === b && db.prepare("select count(*) c from memory where content='同一句话'").get().c === 1, `id ${a}/${b}`);

// ── 2. facts 水位 ──
ensureFacts(db);
const mk = (id, text, self, at) => ({ id, content: text, self, at });
let sample = () => [mk(1, '他说今天降温了', false, 2000), mk(2, '她回了句多穿点', true, 2100)];
setKv(db, 'facts.lastAt', 1000);
let r = await runFactsTick({ db, sample, callLlm: async () => '他吃不惯香菜', ownerId: 'user:master', name: 'Rim', now: 3000 });
check('2a 不足 4 条不抽取', r.added.length === 0 && Number(getKv(db, 'facts.lastAt', 0)) === 1000, `advanced=${r.advanced}`);
check('2b facts 仍为 0', db.prepare('select count(*) c from facts').get().c === 0);

sample = () => [
	mk(3, '他说今天降温了，出门记得把厚外套带上，别又冻着', false, 2000), mk(4, '她说多穿点', true, 2100),
	mk(5, '他明天要早起赶七点的车，估计六点就得出门', false, 2200), mk(6, '他中午想吃面，说楼下那家牛肉面不错', false, 2300),
	mk(7, '他晚上要加班到很晚，可能十一点才回得来', false, 2400)
];
let called = 0;
r = await runFactsTick({
	db, sample, now: 4000, ownerId: 'user:master', name: 'Rim',
	callLlm: async () => { called++; return '他吃不惯香菜'; }
});
check('2c 够 4 条才抽取', called === 1 && r.added.length === 1, JSON.stringify(r.added));
check('2d 抽取后推进水位', Number(getKv(db, 'facts.lastAt', 0)) === 2400, String(getKv(db, 'facts.lastAt', 0)));
check('2e facts 落库', db.prepare('select count(*) c from facts').get().c === 1);

// ── 2f. 积压分批：一次只处理前 12 条，水位只推进到处理过的地方 ──
setKv(db, 'facts.lastAt', 5000);
const many = Array.from({ length: 20 }, (_, i) => ({ id: 100 + i, content: `他说的第${i + 1}件事，内容够长能超过四十个字符的限制吧`, self: false, at: 5000 + (i + 1) * 100 }));
let calls2 = 0;
const r2 = await runFactsTick({ db, sample: () => many, now: 9000, ownerId: 'user:master', name: 'Rim', callLlm: async () => { calls2++; return '他喜欢吃面'; } });
check('2f 积压一次只处理 12 条', calls2 === 1 && r2.processed === 12, JSON.stringify({ calls2, processed: r2.processed }));
check('2g 水位推进到第 12 条', Number(getKv(db, 'facts.lastAt', 0)) === 6200, String(getKv(db, 'facts.lastAt', 0)));

// ── 2h. 模型失败时不能推进水位（否则会永久跳过这段对话） ──
setKv(db, 'facts.lastAt', 7000);
const before = Number(getKv(db, 'facts.lastAt', 0));
const rowsFail = [
	{ id: 201, content: '他说今天天气不错适合出门走走，风也不大', self: false, at: 7100 },
	{ id: 202, content: '他说晚上想吃火锅，最好别太辣的那种', self: false, at: 7200 },
	{ id: 203, content: '他说周末打算去趟书店，把上回没买的书补上', self: false, at: 7300 },
	{ id: 204, content: '他说最近睡得不太好，想早点躺下试试', self: false, at: 7400 }
];
const failed = await runFactsTick({ db, sample: () => rowsFail, now: 9000, callLlm: async () => null });
check('2h 模型没回时不推进水位', failed.advanced === false && Number(getKv(db, 'facts.lastAt', 0)) === before, JSON.stringify(failed));
check('2i 失败原因有记录', !!getKv(db, 'facts.lastError', null));

// ── 3. goals 额度脏计数 ──
const dayKey = `goals.calls.${new Date().toISOString().slice(0, 10)}`;
const H = 3600_000;
const base = Date.now() - 8 * H;
const g = goals.addGoal(db, { title: '验收目标', now: base });
setKv(db, dayKey, 3);
const blocked = await goals.advanceGoal({ db, now: Date.now(), callLlm: async () => '下一步：动手' });
check('3a 脏计数会挡住推进', blocked === null);
setKv(db, dayKey, 0);
const ok = await goals.advanceGoal({ db, now: Date.now(), callLlm: async () => '下一步：动手' });
check('3b 清零后恢复推进', ok?.kind === 'step' && ok.text === '动手', JSON.stringify(ok));

console.log(`\n结果：通过 ${pass} / ${pass + fail}`);
db.close();
process.exit(fail === 0 ? 0 : 1);
