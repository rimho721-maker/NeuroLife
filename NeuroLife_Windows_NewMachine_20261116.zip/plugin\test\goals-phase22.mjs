/**
 * Phase 2.2 验收测试：状态安全 / 认知可靠性 / 事务与审计
 *
 * 全部在临时数据库上跑（openDatabase(path)），不碰真库。
 * 运行：node test/goals-phase22.mjs
 */
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { readFileSync } from 'node:fs';

const lib = new URL('../lib/', import.meta.url).href;
const { openDatabase, getKv, setKv } = await import(lib + 'db.js');
const g = await import(lib + 'goals.js');
const alive = await import(lib + 'alive.js');

const dir = mkdtempSync(join(tmpdir(), 'goals-phase22-'));
const db = openDatabase(join(dir, 'soul.db'));

let pass = 0;
let fail = 0;
function check(name, ok, detail = '') {
	if (ok) { pass++; console.log(`PASS  ${name}${detail ? '  — ' + detail : ''}`); }
	else { fail++; console.log(`FAIL  ${name}${detail ? '  — ' + detail : ''}`); }
}

const H = 3600_000;
const D = 24 * H;
const base = Date.UTC(2026, 10, 12, 4, 0, 0);

// ── P0.1 承诺超过 30 天不再自动作废，只提醒 ──
setKv(db, 'alive.promises', [{ id: 'pOLD', what: '欠你的那张画', at: base - 40 * D, status: 'open', progress: '' }]);
const line = alive.promisesLine(db, base);
const kept = getKv(db, 'alive.promises', []).find((x) => x.id === 'pOLD');
check('P0.1 超时承诺不被自动作废', kept?.status === 'open', JSON.stringify(kept?.status));
check('P0.1b 提示里显示拖了多久', /拖了 40 天/.test(line), line.slice(0, 60));

// ── P0.5/P0.6 工具失败必须带明确 goalId ──
const a = g.addGoal(db, { title: '把欠Rim的那张画完', now: base });
check('P0.5 无 goalId 不记录失败', g.recordToolFailure(db, { goalId: 0, tool: 'draw_image', error: '面板拒绝' }).ok === false);
check('P0.5b 不存在的 goalId 不记录', g.recordToolFailure(db, { goalId: 99999, tool: 'draw_image', error: 'x' }).ok === false);
g.recordToolFailure(db, { goalId: a.id, tool: 'draw_image', error: '面板拒绝', now: base + H });
const rowA = db.prepare('select fail_count, review from goals where id=?').get(a.id);
check('P0.5c 明确 goalId 才记录', rowA.fail_count === 1);
check('P1.1 失败不写 review', rowA.review === '', rowA.review);

// ── P1.2 失败摘要动态生成 ──
const fsum = g.failureSummary(db, a.id);
check('P1.2 失败摘要来自 failures', /第 1 次没成/.test(fsum) && /面板拒绝/.test(fsum), fsum);

// ── P1.3 自动暂停三条件 ──
const c = g.addGoal(db, { title: '整理旧画稿', now: base });
g.recordFailure(db, c.id, { attempt: '先扫一遍', error: '扫到一半电脑蓝屏', now: base + H });
g.recordFailure(db, c.id, { attempt: '再扫', error: '又蓝屏', now: base + 2 * H });
g.logEvent(db, c.id, 'wanted-to-drop', '没时间', base + 3 * H);
const noPause = g.maybeAutoPause(db, { now: base + 6 * D });
check('P1.3 条件不足不暂停', noPause.length === 0, JSON.stringify(noPause));
g.logEvent(db, c.id, 'wanted-to-drop', '还是不想弄', base + 4 * H);
const paused = g.maybeAutoPause(db, { now: base + 8 * D });
const rowC = db.prepare('select status, paused_at from goals where id=?').get(c.id);
check('P1.3b 三条件齐 → paused', rowC.status === 'paused' && paused.length === 1, JSON.stringify(paused.map((x) => x.title)));
check('P1.4 自动暂停不是 dropped', rowC.status !== 'dropped');

// ── P1.5 paused 可恢复、不占 active 名额 ──
for (let i = 0; i < 5; i++) g.addGoal(db, { title: `占位目标 ${i}`, now: base + i });
const activeBefore = db.prepare("select count(*) c from goals where status='active'").get().c;
check('P1.5 paused 不占 active 名额', activeBefore === 6, `active=${activeBefore}`);
const resumed = g.resumeGoal(db, c.id, { now: base + 9 * D });
check('P1.5b 可恢复', resumed.ok === true && db.prepare('select status from goals where id=?').get(c.id).status === 'active');
g.pauseGoal(db, c.id, { reason: '收起来', now: base + 9 * D });

// ── P1.7 公平轮转 + 预算 ──
// 先把前面测试留下的 active 目标结掉，避免 active 上限干扰
for (const r of db.prepare("select id from goals where status='active'").all()) g.closeGoal(db, r.id, { why: '测试清理', now: base + 9 * D });
const x = g.addGoal(db, { title: '目标甲', now: base });
const y = g.addGoal(db, { title: '目标乙', now: base });
const order = [];
const fakeStep = async () => '下一步：做一点';
await g.advanceGoal({ db, now: base + 7 * H, callLlm: fakeStep });
order.push(db.prepare('select title from goals where last_auto_attempt_at = ?').all(base + 7 * H).map((r) => r.title)[0]);
await g.advanceGoal({ db, now: base + 8 * H, callLlm: fakeStep });
order.push(db.prepare('select title from goals where last_auto_attempt_at = ?').all(base + 8 * H).map((r) => r.title)[0]);
check('P1.7 轮转不重复挑同一目标', order[0] !== order[1] && order[0] && order[1], order.join(' → '));
await g.advanceGoal({ db, now: base + 9 * H, callLlm: fakeStep });
const budget = await g.advanceGoal({ db, now: base + 10 * H, callLlm: fakeStep });
check('P1.6 每日预算仍为 3 次', budget === null);

// ── P2 同一连接事务：中途失败整体回滚 ──
const z = g.addGoal(db, { title: '事务测试', now: base });
try {
	db.exec('BEGIN');
	g.stepGoal(db, z.id, '第一步', { now: base + H });
	throw new Error('模拟中途崩溃');
	db.exec('COMMIT');
} catch {
	try { db.exec('ROLLBACK'); } catch { /* 已回滚 */ }
}
const zRow = db.prepare('select steps from goals where id=?').get(z.id);
check('P2 事务内失败可整体回滚', JSON.parse(zRow.steps).length === 0);

// ── P0.4 承诺作废 → 目标只暂停不关闭 ──
const w = g.addGoal(db, { title: '关联承诺的目标', promiseId: 'pDROP', now: base });
g.syncGoalsWithPromises(db, [{ id: 'pDROP', status: 'dropped' }], { now: base + H });
const wRow = db.prepare('select status from goals where id=?').get(w.id);
check('P2.2 承诺作废只暂停目标', wRow.status === 'paused');
const w2 = g.syncGoalsWithPromises(db, [{ id: 'pDROP', status: 'dropped' }], { now: base + 2 * H });
check('P2.2b 重复同步幂等', w2.length === 0);

// ── P0.3 静态审计：所有拼提示的函数都不写库 ──
const sources = {
	alive: readFileSync(new URL('../lib/alive.js', import.meta.url), 'utf8'),
	goals: readFileSync(new URL('../lib/goals.js', import.meta.url), 'utf8'),
	facts: readFileSync(new URL('../lib/facts.js', import.meta.url), 'utf8'),
	relate: readFileSync(new URL('../lib/relate.js', import.meta.url), 'utf8')
};
function fnBody(src, name) {
	const m = src.match(new RegExp(`export function ${name}[\\s\\S]*?\\n}`));
	return m ? m[0] : '';
}
const promptFns = [
	['alive', 'deedsLine'], ['alive', 'promisesLine'], ['alive', 'gapLine'], ['alive', 'energyLine'],
	['alive', 'tabooLine'], ['alive', 'refuseLine'], ['alive', 'wantsLine'],
	['goals', 'goalsLine'], ['facts', 'factsLine'], ['relate', 'relateLines']
];
const dirty = [];
for (const [file, fn] of promptFns) {
	const body = fnBody(sources[file], fn);
	if (body === '') { dirty.push(`${fn}(找不到)`); continue; }
	if (/setKv\(|writeList\(|resolvePromise\(|INSERT INTO|UPDATE /i.test(body)) dirty.push(fn);
}
check('P0.3c 拼提示的函数均无写操作', dirty.length === 0, dirty.join(', '));

// ── P0.3b 静态审计：提示路径里不再有自动作废承诺 ──
check('P0.3d promisesLine 不再 resolvePromise', !/resolvePromise/.test(fnBody(sources.alive, 'promisesLine')));

// ── P4 解析器容错（含真实模型常见形态） ──
const p1 = g.parseAdvanceOutput('今天先给Rim那张画起个墨稿，把落款位置和用色定下来，留白留够。');
check('P4.1 无前缀整句 → 一步', p1.kind === 'step' && p1.text.startsWith('今天先'), p1.text);
const p2 = g.parseAdvanceOutput('「下一步：先只画线稿」');
check('P4.2 去引号 + 去前缀', p2.kind === 'step' && p2.text === '先只画线稿', p2.text);
const p3 = g.parseAdvanceOutput('复盘：上次想直接上色，线稿没定\n下一步：先定线稿，再分两遍上色');
check('P4.3 复盘与下一步混写（换行）', p3.kind === 'step' && /线稿没定/.test(p3.review) && p3.text === '先定线稿，再分两遍上色', JSON.stringify(p3));
const p4 = g.parseAdvanceOutput('   ');
check('P4.4 空输出 → none', p4.kind === 'none');
const p5 = g.parseAdvanceOutput('放弃：实在没时间');
check('P4.5 放弃 → drop 且不改状态', p5.kind === 'drop' && p5.reason === '实在没时间');
const p6 = g.parseAdvanceOutput('复盘：方向可能不对');
check('P4.6 只有复盘 → review', p6.kind === 'review' && p6.review === '方向可能不对');

console.log(`\n结果：通过 ${pass} / ${pass + fail}`);
db.close();
process.exit(fail === 0 ? 0 : 1);
