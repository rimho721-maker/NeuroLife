# 包内容与文件来源

## 包含

- `plugin\`：当前正式插件源码，143 文件
- `profile\`：独立 profile 注册模板、cordis patch、workspace 模板、锁文件参考
- `config\fish-soul-config.template.json`：脱敏配置模板，全部私密值均为占位符
- `synthetic\`：纯合成验收数据，不对应真实人物/记录
- `docs\`：安装、数据库、验收、外部依赖说明
- `MANIFEST.sha256`：本包所有文件哈希

## 明确不包含

- 原人格或人格数据库
- `soul.db`、`chat-archive.db`、`neurolife-self-model.sqlite`
- 任何 `-wal` / `-shm`
- 聊天记录、会话日志
- 旧向量索引或 embedding 缓存
- 附件、图片、音频、贴纸
- API Key、QQ accessToken、Cookie、Token
- 原机路径 `F:\AI\...`、`C:\Users\34894\...` 的配置值

## 数据库初始化与迁移

本包不附带数据库转储，只附带源码。首次加载插件时：

- `plugin\lib\db.js` 打开/创建 `soul.db` 并执行建表
- `plugin\lib\soul-memory.js` 负责记忆表与迁移
- `plugin\lib\chat-archive.js` 创建 `chat-archive.db`
- `plugin\lib\autonomy-self-store.mjs` 创建 `neurolife-self-model.sqlite`
- 其他模块用 `CREATE TABLE IF NOT EXISTS` 做增量初始化

新机从空库启动即可；不要复制原机数据库。

## 合成数据

`synthetic\memories.json` 与 `synthetic\thoughts.json` 只用于验收：

- 金额冲突
- 偏好变化
- 重复约定
- 计划类 Thought

导入脚本/步骤由验收人员按新机实际 API 执行；不要写入生产库。
