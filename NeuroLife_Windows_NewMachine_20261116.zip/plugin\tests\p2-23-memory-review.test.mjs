import test from 'node:test';
import assert from 'node:assert/strict';
import { SelfModelStore } from '../lib/autonomy-self-store.mjs';
import { memoryReviewOwnerDecision, runSubmitMemoryReviewTool } from '../lib/autonomy-self-model.mjs';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

test('memory review submit is stable and duplicate-safe across restart', () => {
  const dir=mkdtempSync(join(tmpdir(),'p223-memory-')); const db=join(dir,'self.sqlite');
  const review={title:'确认欠款数额',finding:'先记 160 文，后出现 175 文，未记录改口原因。',evidenceSummary:'长期记忆中两条相关记录，均为脱敏摘要。',uncertainty:'可能记错，也可能增加了金额。',recommendation:'请 Owner 确认 160 或 175。'};
  try {
    const a=new SelfModelStore(db); const r1=a.submitMemoryReview(review,1000); assert.match(r1.proposalId,/^p223-[a-f0-9]{32}$/); assert.equal(r1.duplicate,false); assert.equal(a.view().proposals.length,1);
    const r2=a.submitMemoryReview(review,2000); assert.equal(r2.proposalId,r1.proposalId); assert.equal(r2.duplicate,true); assert.equal(a.view().proposals.length,1);
    const reviewed=a.reviewProposal(r1.proposalId,'accept','USEFUL',3000); assert.equal(reviewed.proposals[0].status,'ACCEPTED_FOR_REVIEW'); a.close();
    const b=new SelfModelStore(db); const v=b.view(); assert.equal(v.proposals.length,1); assert.equal(v.proposals[0].proposalId,r1.proposalId); assert.equal(v.proposals[0].status,'ACCEPTED_FOR_REVIEW'); assert.equal(v.reviews.length,1);
    const r3=b.submitMemoryReview(review,4000); assert.equal(r3.proposalId,r1.proposalId); assert.equal(r3.duplicate,true); assert.equal(b.view().proposals.length,1); b.close();
  } finally { rmSync(dir,{recursive:true,force:true}); }
});

test('Owner tool access requires trusted host principal, not a desktop default', () => {
  assert.equal(memoryReviewOwnerDecision({toolCtx:{principal:{kind:'owner'}}}).ok,true);
  assert.equal(memoryReviewOwnerDecision({toolCtx:{agent:{id:'desktop-session'}}}).ok,false);
  assert.equal(memoryReviewOwnerDecision({toolCtx:{agent:{id:'desktop-session'},principal:{kind:'guest'}}}).ok,false);
  assert.equal(memoryReviewOwnerDecision({toolCtx:{}}).ok,false);
});

test('unknown Owner identity leaves proposal count unchanged', () => {
  const dir=mkdtempSync(join(tmpdir(),'p223-owner-')); const db=join(dir,'self.sqlite');
  try {
    const s=new SelfModelStore(db); const before=s.view().proposals.length;
    const access=memoryReviewOwnerDecision({toolCtx:{agent:{id:'desktop-session'}}});
    assert.equal(access.ok,false); assert.equal(s.view().proposals.length,before); s.close();
  } finally { rmSync(dir,{recursive:true,force:true}); }
});

test('actual tool execution entry rejects unknown desktop identity without submitting', () => {
  let calls=0;
  const result=runSubmitMemoryReviewTool({toolCtx:{agent:{id:'desktop-session'}},args:{title:'x'},submit:()=>{calls++;return {proposalId:'p223-x',duplicate:false};}});
  assert.equal(result.ok,false); assert.equal(calls,0); assert.match(result.text,/Owner/);
});
