# 外部依赖与可选服务

## 随包提供

- dsh-fish-soul 插件源码 0.15.30
- profile 注册模板
- 配置模板（占位符）
- 合成验收数据
- 数据库初始化代码（在插件源码内）

## 新机必须安装

| 项 | 说明 |
|---|---|
| DSH Desktop 0.2.1-rc.5 | Windows x64；匹配版本 |
| Node 24.21.0 或兼容 | DSH 自带 runtime 可直接使用 |
| pnpm 11.28.5 或兼容 | 安装 profile 依赖 |
| dsh-fish-soul 的宿主 peer | `@deepseek-ai/dsh-tools`、`@deepseek-ai/schemastery`（通常由 DSH 提供） |

## 可选服务

### Embedding

- 配置键：`embedding.enabled`、`baseURL`、`apiKey`、`model`
- 需要新机自行提供 OpenAI 兼容 embedding 服务，例如本地 `bge-small-zh-v1.5`
- 未配置时：向量召回/语义检索不可用；文本级记忆仍可验证
- 本包不含模型权重、Python 服务或 API Key

### QQ

- 配置键：`qq.wsUrl`、`qq.accessToken`、`masterQqUin`
- 需要新机安装兼容 SnowLuma/OneBot WebSocket 端并填写自己的 Token/UIN
- 本包不含 QQ 客户端、协议端或凭据

### 绘图 / 外部服务

- 在 DSH 插件设置中单独配置 OpenAI 兼容图像服务
- 可能需要 Python + Pillow（用于图片处理），具体取决于启用的面板/脚本
- 本包不含 Python 环境、模型、密钥

### 语音 STT/TTS

- 可选；需要自行配置 STT/TTS endpoint、模型和凭据
- 本包不含语音模型或密钥

### 其他 DSH 插件

原 profile 还包含：

- `dshmarket`
- `dsh-whale-widget`
- `dsh-see-now`
- `@vectorize-io/hindsight-coding-agents`

它们不在本包内，需要新机按需安装；不安装不影响 RamKo 基础插件加载。

## 不随包提供

- DSH 安装包
- pnpm 安装包
- 原机数据库/人格/聊天记录
- 任何真实 API Key、Token、Cookie
- 原机绝对路径配置
