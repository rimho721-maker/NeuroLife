# 安装辅助

本目录预留新机安装辅助文件位置；当前安装步骤以 `docs/INSTALL.md` 为准。

如需自动化：

1. 先由 DSH 首次启动创建 `DSH_HOME`
2. 用 `profile/package.json.template` 生成 profile
3. 按 `docs/INSTALL.md` 创建 Junction
4. 在 profile 内运行 `pnpm install`

不要把原机绝对路径写入脚本或模板。
