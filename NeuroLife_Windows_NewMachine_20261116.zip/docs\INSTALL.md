# NeuroLife Windows 新机安装说明

本包是 **新机测试包**，不含原机人格、真实数据库、聊天记录、附件、日志、向量索引、API Key、Token 或 Cookie。

## 0. 匹配版本

- DSH Desktop：**0.2.1-rc.5**（Windows x64）
- Node：**24.21.0**（DSH 自带 runtime 可用）
- dsh-fish-soul：**0.15.30**
- pnpm：建议 **11.28.5**（DSH profile 安装使用）

## 1. 选择新机路径

以下路径只是示例，可替换成任意目录：

```text
C:\NeuroLife\dsd-home
C:\NeuroLife\plugin
C:\NeuroLife\workspace
```

不要把本包解压到原机路径，也不要复用原机的 `.dsh`。

## 2. 安装 DSH

1. 安装匹配版本 DSH Desktop 0.2.1-rc.5。
2. 首次启动一次，让它创建基础目录，然后正常退出。
3. 新建独立 DSH_HOME，例如：

```text
C:\NeuroLife\dsd-home
```

4. 在启动 DSH 的快捷方式/独立 PowerShell 中设置：

```powershell
$env:DSH_HOME = 'C:\NeuroLife\dsd-home'
Start-Process -FilePath 'C:\Program Files\DSH\DeepSeek Harness.exe'
```

以后每次启动新机 DSH 都使用同一 `DSH_HOME`。

## 3. 安装插件源码

把包中的 `plugin\` 复制到：

```text
C:\NeuroLife\plugin
```

不要复制任何 `.sqlite`、`.db`、`-wal`、`-shm` 文件；本包本来也不包含它们。

## 4. 创建独立 profile

在：

```text
C:\NeuroLife\dsd-home\profiles\desktop
```

创建 profile 目录，并复制：

```text
profile\package.json.template  ->  ...\profiles\desktop\package.json
profile\cordis.patch.yml       ->  ...\profiles\desktop\cordis.patch.yml
profile\pnpm-workspace.yaml    ->  ...\profiles\desktop\pnpm-workspace.yaml
```

编辑 `package.json`：

```text
{{PLUGIN_PATH}}  ->  C:\NeuroLife\plugin
```

建议把依赖收敛为最小集合：

```json
{
  "dependencies": {
    "dsh-fish-soul": "link:C:\\NeuroLife\\plugin"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "dsh-fish-soul"
      ]
    }
  }
}
```

如果还要用其他插件（`dshmarket`、`dsh-see-now`、`dsh-whale-widget`、Hindsight），按原样加入依赖和 bundles；它们不在本包内，需要新机安装。

## 5. 链接插件

在 profile 目录创建 Junction：

```powershell
New-Item -ItemType Directory -Force 'C:\NeuroLife\dsd-home\profiles\desktop\node_modules' | Out-Null
New-Item -ItemType Junction `
  -Path 'C:\NeuroLife\dsd-home\profiles\desktop\node_modules\dsh-fish-soul' `
  -Target 'C:\NeuroLife\plugin'
```

确认：

```powershell
(Get-Item 'C:\NeuroLife\dsd-home\profiles\desktop\node_modules\dsh-fish-soul' -Force).Target
```

## 6. 安装依赖

在 profile 目录运行：

```powershell
cd 'C:\NeuroLife\dsd-home\profiles\desktop'
pnpm install
```

`pnpm-lock.reference.yaml` 是原机锁文件参考，里面的 `{{PLUGIN_PATH}}` 不是有效路径；首次安装请让 pnpm 重新生成当前机器的 lock，不要直接照搬原机绝对路径。

## 7. 首次启动与数据库

首次启动会在 `DSH_HOME` 下生成：

```text
C:\NeuroLife\dsd-home\fish-soul\soul.db
C:\NeuroLife\dsd-home\fish-soul\chat-archive.db
C:\NeuroLife\dsd-home\fish-soul\neurolife-self-model.sqlite
C:\NeuroLife\dsd-home\fish-soul\neurolife-self-model.sqlite-wal
C:\NeuroLife\dsd-home\fish-soul\neurolife-self-model.sqlite-shm
```

- `soul.db`：人格、记忆、关系、日程等主库
- `chat-archive.db`：聊天文本归档
- `neurolife-self-model.sqlite`：P2-23 自我模型/记忆审阅提案
- 这些文件由插件首次打开时自动建表；不需要手工执行 SQL
- 数据库初始化代码在 `plugin\lib\db.js`、`plugin\lib\soul-memory.js`、`plugin\lib\chat-archive.js`、`plugin\lib\autonomy-self-store.mjs`

配置模板复制到：

```text
C:\NeuroLife\dsd-home\fish-soul-config.json
```

并替换占位符；不要从原机复制真实配置文件。

## 8. 创建新人格

启动 DSH，打开 RamKo：

```text
RamKo → 人格 / 设置
```

创建一个**全新人格**，不要导入原机人格或数据库。  
新人格应从空库开始，首次聊天会创建新的 `soul.db` 数据。

## 9. 插件注册检查

启动后打开 DSH 插件页，确认：

```text
dsh-fish-soul
```

已加载。  
若插件页为空，检查：

1. profile 的 `package.json` 中 `dsh.profile.bundles` 含 `dsh-fish-soul`
2. `node_modules\dsh-fish-soul` Junction 指向 `C:\NeuroLife\plugin`
3. 当前 Host 实际使用的 profile 是否是 `C:\NeuroLife\dsd-home\profiles\desktop`
4. `DSH_HOME` 是否在启动前设置

## 10. 新机验收顺序

1. 插件注册成功
2. RamKo 能打开
3. 创建新人格
4. 聊天收发
5. 合成记忆写入和召回
6. 提交并审核测试提案
7. 向量召回
8. 定期记忆审阅

第 7、8 项依赖 Embedding 服务；若未配置，应标为“待验证”，不要当作失败。
