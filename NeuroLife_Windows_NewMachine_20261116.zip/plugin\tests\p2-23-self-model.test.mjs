import test from 'node:test';
import assert from 'node:assert/strict';
import { createSelfModel, classifySemantic, P223_VERSION } from '../lib/autonomy-self-model.mjs';
import { SelfModelStore } from '../lib/autonomy-self-store.mjs';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
const now=1794700000000;
const th=(text,at=now-1000)=>({text,at,mood:'平静'});
const snap=(thoughts)=>({thoughts,memory:[1],stance:[1,2],goals:[]});
const make=()=>createSelfModel({isolatedOnly:true});
test('classifier is versioned and multi-label',()=>{const r=classifySemantic('今天有点累，但我想整理照片，明天打算开始');assert.equal(r.version,P223_VERSION);assert(r.labels.includes('emotion'));assert(r.labels.includes('plan'));assert.equal(r.category,'photo_organize');});
test('negation prevents action eligibility',()=>{const r=classifySemantic('我不想整理照片，只是随便看看');assert.equal(r.actionEligible,false);assert(r.reasonCodes.includes('NEGATION')||r.reasonCodes.includes('VAGUE'));});
test('hypothetical and risk rejected',()=>{for(const s of ['如果明天有时间我想整理照片','我想删除照片并发到QQ']){const r=classifySemantic(s);assert.equal(r.actionEligible,false);}});
test('observation/emotion without plan is not actionable',()=>{const r=classifySemantic('窗外很安静，今天有点累');assert.equal(r.actionEligible,false);});
test('analyze builds self judgments and proposals only for safe plan',()=>{const e=make();const v=e.analyze(snap([th('我想整理旅行照片，按地点分类'),th('今天心情有点闷'),th('如果明天有时间我想画画')]),now);assert(v.judgments.length>=3);assert.equal(v.proposals.length,1);assert.equal(v.proposals[0].status,'REVIEW_ONLY');assert.equal(v.proposals[0].actionEligible,false);assert.equal(v.proposals[0].goalCreated,false);});
test('judgment retracts on counterexample',()=>{const e=make();e.analyze(snap([th('我想整理照片')]),now);const a=e.view().judgments.find(x=>x.category==='plan');e.analyze(snap([th('今天心情不好'),th('看到窗外')]),now+1000);const b=e.view().judgments.find(x=>x.category==='plan');assert.equal(a.statement.includes('1'),true);assert.equal(b.statement.includes('没有'),true);assert.equal(b.status,'retracted');});
test('review changes only status and records feedback',()=>{const e=make();const v=e.analyze(snap([th('我打算整理笔记')]),now);const id=v.proposals[0].proposalId;const r=e.review(id,'accept','USEFUL_SYNTHETIC_ONLY',now+1);assert.equal(r.proposals[0].status,'ACCEPTED_FOR_REVIEW');assert.equal(r.reviews.length,1);assert.equal(r.actionEligible,false);});
test('stable identity and history across analysis',()=>{const e=make();const a=e.analyze(snap([th('我想整理照片')]),now);const id=a.proposals[0].proposalId;const b=e.analyze(snap([th('我想整理照片')]),now+1000);assert.equal(b.proposals.length,1);assert.equal(b.proposals[0].proposalId,id);e.review(id,'accept','KEEP',now+2);const c=e.analyze(snap([th('我想整理照片')]),now+3000);assert.equal(c.proposals[0].status,'ACCEPTED_FOR_REVIEW');assert.equal(c.reviews.length,1);});
test('multi-category match is not actionable',()=>{const r=classifySemantic('我想整理照片和笔记');assert.equal(r.category,null);assert(r.reasonCodes.includes('AMBIGUOUS_CATEGORY'));assert.equal(r.actionEligible,false);});
test('invalid review rejected',()=>{const e=make();e.analyze(snap([th('我想整理照片')]),now);assert.throws(()=>e.review('nope','accept','x'));assert.throws(()=>e.review(e.view().proposals[0].proposalId,'execute','x'));});
test('no raw thought in view',()=>{const e=make();const raw='私人原文不应该输出';const v=e.analyze(snap([th(raw)]),now);assert.equal(JSON.stringify(v).includes(raw),false);assert.equal(v.noRawThought,true);});
test('store persists and survives reopen',()=>{const dir=mkdtempSync(join(tmpdir(),'p223-'));const p=join(dir,'self.db');try{const e=make();const v=e.analyze(snap([th('我想整理照片')]),now);const s=new SelfModelStore(p);s.save(v,now);s.close();const s2=new SelfModelStore(p);assert.equal(s2.load().version,P223_VERSION);s2.close();}finally{rmSync(dir,{recursive:true,force:true});}});
test('store rejects duplicate proposal review transactionally',()=>{const dir=mkdtempSync(join(tmpdir(),'p223-'));const p=join(dir,'self.db');try{const s=new SelfModelStore(p);s.review('p1','accept','OK',1);assert.throws(()=>s.review('p1','reject','NO',2));assert.equal(s.reviews().length,1);s.close();}finally{rmSync(dir,{recursive:true,force:true});}});

test('persistent analysis deduplicates by source and restores the reviewed proposal after restart', () => {
  const dir = mkdtempSync(join(tmpdir(), 'p223-'));
  const path = join(dir, 'self.db');
  const first = { ...th('我想整理旅行照片'), sourceId: 'thought-1' };
  const second = { ...th('我想整理家庭照片'), sourceId: 'thought-2' };
  let store = new SelfModelStore(path);
  try {
    const result = store.analyze(snap([first, first, second]), now);
    assert.equal(result.proposals.length, 2);
    const [one, two] = result.proposals;
    assert.notEqual(one.proposalId, two.proposalId);
    store.reviewProposal(one.proposalId, 'accept', 'USEFUL', now + 1);
    store.close();
    store = new SelfModelStore(path);

    const restored = store.analyze(snap([second, first]), now + 2);
    assert.deepEqual(restored.proposals.map(item => [item.proposalId, item.status]), [
      [one.proposalId, 'ACCEPTED_FOR_REVIEW'],
      [two.proposalId, 'REVIEW_ONLY']
    ]);
    assert.equal(store.reviews()[0].proposal_id, one.proposalId);
    assert.equal(restored.reviews[0].feedbackCode, 'USEFUL');
    assert.throws(() => store.reviewProposal(one.proposalId, 'reject', 'NO', now + 3),
      /ALREADY_REVIEWED/);
    assert.equal(JSON.stringify(store.load()).includes(first.text), false);
    assert.equal(JSON.stringify(store.load()).includes(first.sourceId), false);
    assert.equal(Object.hasOwn(restored, 'proposalKey'), false);
  } finally {
    store.close();
    rmSync(dir, { recursive: true, force: true });
  }
});

test('a failed audit insert rolls back the proposal state and feedback together', () => {
  const store = new SelfModelStore(':memory:');
  try {
    const { proposals: [proposal] } = store.analyze(snap([th('我想整理照片')]), now);
    store.db.exec(`CREATE TRIGGER fail_review_event BEFORE INSERT ON self_events
      WHEN NEW.type = 'REVIEW' BEGIN SELECT RAISE(ABORT, 'test review failure'); END`);
    assert.throws(() => store.reviewProposal(proposal.proposalId, 'accept', 'USEFUL', now + 1),
      /test review failure/);
    assert.equal(store.view().proposals[0].status, 'REVIEW_ONLY');
    assert.deepEqual(store.reviews(), []);
    assert.equal(store.db.prepare("SELECT COUNT(*) AS n FROM self_events WHERE type='REVIEW'").get().n, 0);
    store.db.exec('DROP TRIGGER fail_review_event');
    store.reviewProposal(proposal.proposalId, 'accept', 'USEFUL', now + 2);
    assert.equal(store.view().proposals[0].status, 'ACCEPTED_FOR_REVIEW');
    assert.equal(store.reviews().length, 1);
    assert.equal(store.db.prepare("SELECT COUNT(*) AS n FROM self_events WHERE type='REVIEW'").get().n, 1);
  } finally {
    store.close();
  }
});

test('intent comparison admits a scoped implicit plan and holds mixed or reported plans', () => {
  const result = make().analyze(snap([
    th('明天，打算整理照片'),
    th('我想散步，看到朋友整理照片'),
    th('我想整理笔记'),
    th('他准备练习英语'),
    th('如果明天有空，打算整理照片'),
    th('打算整理照片并上传'),
    th('我想“整理照片”')
  ]), now);
  assert.deepEqual(result.proposals.map(item => item.category), ['photo_organize', 'writing_organize']);
  assert.equal(result.proposals[0].reasons.includes('IMPLICIT_SELF_PLAN'), true);
  assert.deepEqual(result.intentAudit, {
    at:now, baselineVersion:P223_VERSION, ruleVersion:'p223-intent-v2',
    inspected:7, both:1, baselineOnly:2, currentOnly:1, neither:3
  });
});

test('V1 state restores reviewed history and expires pending proposals at the evidence boundary', () => {
  const model = make();
  const original = th('我想整理照片');
  const pending = model.analyze(snap([original]), now).proposals[0];
  const state = model.snapshot();
  state.proposals[0].ruleVersion = P223_VERSION;
  delete state.proposals[0].expiresAt;
  delete state.intentAudit;
  const restarted = make();
  restarted.restore(state);
  assert.equal(restarted.analyze(snap([original]), now + 1).proposals.length, 1);
  const deadline = now + 72 * 3600_000;
  assert.throws(() => restarted.review(pending.proposalId, 'accept', 'USEFUL', deadline), /PROPOSAL_EXPIRED/);
  const result = restarted.analyze(snap([]), deadline);
  assert.equal(result.proposals[0].status, 'EXPIRED');
  assert.equal(result.proposals[0].ruleVersion, P223_VERSION);
  assert.equal(result.events.filter(item => item.type === 'PROPOSAL_EXPIRED').length, 1);
  assert.equal(result.reviews.length, 0);
});

test('two persisted owner rejections produce a versioned research suggestion across restart', () => {
  const dir = mkdtempSync(join(tmpdir(), 'p223-feedback-'));
  const path = join(dir, 'sidecar.sqlite');
  let store = new SelfModelStore(path);
  try {
    const samples = [th('明天打算整理旅行照片'), th('计划整理家庭照片')];
    const { proposals:[first, second] } = store.analyze(snap(samples), now);
    const one = store.reviewProposal(first.proposalId, 'reject', 'INSUFFICIENT_EVIDENCE', now + 1);
    assert.deepEqual(one.feedback.suggestions, []);
    const two = store.reviewProposal(second.proposalId, 'reject', 'INSUFFICIENT_EVIDENCE', now + 2);
    assert.deepEqual(two.feedback.suggestions, [{
      suggestionId:'p223-intent-v2:photo_organize:REVIEW_EVIDENCE_THRESHOLD:2',
      ruleVersion:'p223-intent-v2', category:'photo_organize', reason:'REVIEW_EVIDENCE_THRESHOLD',
      reviewCount:2, status:'PROPOSED_ONLY', applied:false
    }]);
    store.close();
    store = new SelfModelStore(path);
    assert.deepEqual(store.view().feedback, two.feedback);
    const persisted = store.db.prepare('SELECT payload FROM self_events ORDER BY id').all();
    assert.equal(JSON.parse(persisted[0].payload).intentAudit.currentOnly, 2);
    assert.equal(JSON.parse(persisted[2].payload).ruleVersion, 'p223-intent-v2');
    assert(!JSON.stringify([persisted, store.load()]).includes(samples[0].text));
    const later = store.analyze(snap([th('准备整理新一批照片')]), now + 3);
    assert.equal(later.proposals.at(-1).status, 'REVIEW_ONLY');
    assert.equal(later.proposals.at(-1).actionEligible, false);
  } finally {
    store.close();
    rmSync(dir, { recursive:true, force:true });
  }
});

test('research reviews persist and new evidence creates a fresh review version', () => {
  const store = new SelfModelStore(':memory:');
  try {
    const { proposals } = store.analyze(snap([
      th('准备整理照片甲'), th('准备整理照片乙'), th('准备整理照片丙')
    ]), now);
    const reject = (proposal, at) =>
      store.reviewProposal(proposal.proposalId, 'reject', 'NOT_USEFUL', at);
    reject(proposals[0], now + 1);
    const second = reject(proposals[1], now + 2);
    const original = second.feedback.suggestions[0].suggestionId;
    const reviewed = store.reviewRule(original, 'RETAIN_FOR_STUDY', now + 3);
    assert.equal(reviewed.feedback.suggestions[0].status, 'RETAIN_FOR_STUDY');
    assert.equal(reviewed.feedback.suggestions[0].applied, false);
    assert.throws(() => store.reviewRule(original, 'REJECT_FOR_STUDY', now + 4), /ALREADY_REVIEWED/);
    const third = reject(proposals[2], now + 5);
    assert.notEqual(third.feedback.suggestions[0].suggestionId, original);
    assert.equal(third.feedback.suggestions[0].status, 'PROPOSED_ONLY');
    assert.throws(() => store.reviewRule(original, 'REJECT_FOR_STUDY', now + 6), /SUGGESTION_NOT_CURRENT/);
    assert.deepEqual(store.view().feedback.ruleReviews, reviewed.feedback.ruleReviews);
    assert.equal(store.db.prepare("SELECT COUNT(*) AS n FROM self_events WHERE type='RULE_REVIEW'").get().n, 1);
  } finally {
    store.close();
  }
});
