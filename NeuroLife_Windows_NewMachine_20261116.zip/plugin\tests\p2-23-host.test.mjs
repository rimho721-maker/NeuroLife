import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer, request as httpRequest } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { existsSync, mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { once } from 'node:events';
import { readSelfModelSnapshot } from '../lib/autonomy-self-snapshot.js';
import { createSelfModelHost } from '../lib/autonomy-self-host.mjs';
import { handleSelfModelRoute } from '../lib/routes-self-model.mjs';
import { handleP220ProductionThoughtRoute } from '../lib/autonomy-prod-thought-readonly.mjs';
import { ownerGuard } from '../lib/owner-auth.js';

test('private local integration handles consent, counterevidence, review and restart', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'p223-host-'));
  const dbPath = join(dir, 'soul.db');
  const db = new DatabaseSync(dbPath);
  const now = Date.now() - 30 * 60_000;
  db.exec(`
    CREATE TABLE kv (key TEXT PRIMARY KEY,value TEXT);
    CREATE TABLE memory (id INTEGER, owner_id TEXT, status TEXT, valid_to INTEGER, updated_at INTEGER, content TEXT);
    CREATE TABLE stance (id INTEGER, owner_id TEXT, status TEXT, valid_to INTEGER, created_at INTEGER, claim TEXT);
    CREATE TABLE goals (id INTEGER, owner_id TEXT, status TEXT, updated_at INTEGER, title TEXT);
  `);
  db.prepare('INSERT INTO memory VALUES(1,?,?,?,?,?)').run('self', 'active', null, now, '喜欢写作');
  db.prepare('INSERT INTO stance VALUES(1,?,?,?,?,?)').run('user:master', 'active', null, now, '喜欢画画');
  db.prepare('INSERT INTO goals VALUES(1,?,?,?,?)').run('self', 'active', now, '整理家庭照片');
  const write = db.prepare('INSERT OR REPLACE INTO kv VALUES(?,?)');
  write.run('selfmood', JSON.stringify({ at:now, valence:75, intensity:2 }));
  write.run('growth', JSON.stringify({ items:[{ id:'g1', status:'active', updatedAt:now,
    text:'喜欢日语', evidence:[{ day:'1', channelId:'a' }, { day:'1', channelId:'b' }, { day:'2', channelId:'a' }] }] }));
  const thoughts = [
    { text:'我喜欢摄影', sourceId:'private-source-1', at:now },
    { text:'我想整理照片', sourceId:'private-source-2', at:now }
  ];
  write.run('thoughts.stream', JSON.stringify(thoughts));
  let reads = 0;
  const makeHost = () => createSelfModelHost({ dbPath, readSnapshot(at) {
    reads++;
    return readSelfModelSnapshot(db, at);
  } });
  let host = makeHost();
  const peer = { principal:{ kind:'owner', id:'local-owner' } };
  const ctx = { get:() => ({ admit:request => request.headers['x-test-owner'] ? { peer } : { rejection:{ status:401 } } }) };
  const server = createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const send = (status, body, headers) => {
      res.writeHead(status, { 'content-type':'application/json', ...headers });
      res.end(JSON.stringify(body));
    };
    const admitted = ownerGuard(ctx, req);
    if (!admitted.ok) return send(admitted.status, { ok:false });
    if (url.pathname === '/cognition/thought-preview') {
      handleP220ProductionThoughtRoute({ method:req.method, path:url.pathname, url, req, send, db,
        admittedPeer:admitted.peer, enabled:true });
      return;
    }
    await handleSelfModelRoute({ method:req.method, path:url.pathname, url, req, peer:admitted.peer, send, host });
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const origin = `http://127.0.0.1:${server.address().port}`;
  const call = (suffix, body, headers={}) => fetch(origin + '/cognition/self-model' + suffix, {
    method:body ? 'POST' : 'GET',
    headers:{ 'x-test-owner':'yes', ...(body && { origin, 'content-type':'application/json' }), ...headers },
    body:body && JSON.stringify(body)
  });
  try {
    assert.equal((await fetch(origin + '/cognition/self-model')).status, 401);
    const status = await call('');
    assert.equal(status.headers.get('cache-control'), 'no-store');
    assert.deepEqual(await status.json(), { ok:true, enabled:false, model:null });
    assert.equal(host.tick(now), false);
    assert.equal(reads, 0);
    assert.equal(existsSync(join(dir, 'neurolife-self-model.sqlite')), false);
    assert.equal((await call('/settings', { enabled:true }, { origin:'http://example.invalid' })).status, 403);
    const desktopPost = (suffix, body, headers={}) => new Promise((resolve, reject) => {
      const req = httpRequest(origin + '/cognition/self-model' + suffix, {
        method:'POST', headers:{ 'x-test-owner':'yes', 'content-type':'application/json', ...headers }
      }, response => {
        response.resume();
        resolve(response.statusCode);
      });
      req.on('error', reject);
      req.end(JSON.stringify(body));
    });
    assert.equal(await desktopPost('/settings', { enabled:true }, { origin:'null' }), 403);
    assert.equal(await desktopPost('/settings', { enabled:true }, { 'sec-fetch-site':'cross-site' }), 403);
    assert.equal(await desktopPost('/settings', { enabled:true }, { origin:'dsh-app://app' }), 403);
    assert.equal(await desktopPost('/settings', { enabled:true }), 200);
    assert.equal(host.tick(now), true);
    assert.equal(host.tick(now + 1), false);
    const initial = (await (await call('')).json()).model;
    assert.equal(initial.judgments.find(j => j.category === '摄影').status, 'new');
    for (const source of ['memory', 'stance', 'growth', 'goals', 'mood']) {
      assert(initial.judgments.some(j => j.sources.includes(source)), source);
    }
    const preview = await fetch(origin + '/cognition/thought-preview', { headers:{ 'x-test-owner':'yes' } });
    assert.equal(preview.status, 200);
    assert.equal((await preview.json()).writes, 0);
    const { proposalId } = initial.proposals[0];
    const request = { proposalId, decision:'accept', feedbackCode:'USEFUL' };
    const responses = await Promise.all([call('/review', request), call('/review', request)]);
    assert.deepEqual(responses.map(r => r.status).sort(), [200, 409]);
    host.close();
    host = makeHost();
    assert.equal(host.status().enabled, true);
    assert.equal(host.tick(now + 2), false);
    const later = now + 11 * 60_000;
    thoughts.push({ text:'我不再喜欢摄影', sourceId:'private-source-3', at:later });
    write.run('thoughts.stream', JSON.stringify(thoughts));
    assert.equal(host.tick(later), true);
    const updated = (await (await call('')).json()).model;
    assert.equal(updated.judgments.find(j => j.category === '摄影').status, 'retracted');
    assert.equal(updated.judgments.find(j => j.category === '摄影').counterexamples, 1);
    assert.equal(updated.judgments.find(j => j.category === '绘画').counterexamples, 0);
    assert.equal(updated.proposals[0].proposalId, proposalId);
    assert.equal(updated.proposals[0].status, 'ACCEPTED_FOR_REVIEW');
    assert(!JSON.stringify(updated).includes('private-source'));
    assert(!JSON.stringify(updated).includes('我不再喜欢摄影'));
    assert.equal((await call('/settings', { enabled:false })).status, 200);
    assert.equal(host.tick(later + 11 * 60_000), false);
    assert.equal(reads, 2);
    const suggestion = { suggestionId:'p223-intent-v2:photo_organize:REVIEW_EVIDENCE_THRESHOLD:2',
      decision:'RETAIN_FOR_STUDY' };
    assert.equal((await call('/rule-review', suggestion, { origin:'http://example.invalid' })).status, 403);
    assert.equal((await call('/rule-review', { ...suggestion, decision:'APPLY' })).status, 400);
    assert.equal((await call('/rule-review', suggestion)).status, 409);
    const next = later + 11 * 60_000;
    thoughts.push({ text:'打算整理旅行照片', at:next }, { text:'准备整理家庭照片', at:next });
    write.run('thoughts.stream', JSON.stringify(thoughts));
    assert.equal((await call('/settings', { enabled:true })).status, 200);
    assert.equal(host.tick(next), true);
    const pending = host.status().model.proposals.filter(item => item.status === 'REVIEW_ONLY');
    assert.equal(pending.length, 2);
    for (const item of pending) {
      assert.equal((await call('/review', {
        proposalId:item.proposalId, decision:'reject', feedbackCode:'INSUFFICIENT_EVIDENCE'
      })).status, 200);
    }
    assert.equal(await desktopPost('/rule-review', suggestion), 200);
    assert.equal((await call('/rule-review', suggestion)).status, 409);
    host.close();
    host = makeHost();
    assert.equal(host.status().model.feedback.suggestions[0].status, 'RETAIN_FOR_STUDY');
    assert.equal(host.status().model.feedback.suggestions[0].applied, false);
    assert.equal(db.prepare('SELECT count(*) AS n FROM goals').get().n, 1);
  } finally {
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
    host.close();
    db.close();
    rmSync(dir, { recursive:true, force:true });
  }
});
