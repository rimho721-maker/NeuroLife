# NeuroLife Windows 新机测试包

- 插件：dsh-fish-soul **0.15.30**
- 源码：**143 文件**
- DSH：**0.2.1-rc.5**
- Node：**24.21.0**
- 只含源码/模板/合成数据；不含原机人格、数据库、聊天记录、附件、日志、向量或密钥。

## 快速开始

1. 阅读 `docs/INSTALL.md`
2. 复制 `plugin/` 到新机任意路径
3. 按 `profile/package.json.template` 创建独立 profile
4. 安装 DSH 0.2.1-rc.5、pnpm，运行 `pnpm install`
5. 启动 DSH，打开 RamKo，创建新人格

## 安全说明

- 配置模板中所有私密字段都是 `{{PLACEHOLDER}}`
- 插件源码中的原 Owner 私聊频道已替换为 `private:__OWNER_PRIVATE_CHANNEL__`，新机需按自己的频道配置
- 不附带任何真实 API Key、Token、Cookie、数据库

## 验收

见 `docs/ACCEPTANCE.md`。新机未实测项必须标为“待验证”。
