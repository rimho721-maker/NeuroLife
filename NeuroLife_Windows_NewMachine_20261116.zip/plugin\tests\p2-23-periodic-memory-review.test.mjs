import test from 'node:test';
import assert from 'node:assert/strict';
import { createSelfModelHost } from '../lib/autonomy-self-host.mjs';
import { SelfModelStore } from '../lib/autonomy-self-store.mjs';
import { analyzeMemoryReviews } from '../lib/autonomy-memory-review.mjs';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

const now = 1_800_000_000_000;
const rows = [
  { id: 1, content: '欠款 160 文，记着。', created_at: now - 48 * 3600_000 },
  { id: 2, content: '欠款 175 文，之后再算。', created_at: now - 24 * 3600_000 },
  { id: 3, content: '我喜欢摄影。', created_at: now - 40 * 3600_000 },
  { id: 4, content: '我不喜欢摄影了。', created_at: now - 20 * 3600_000 },
  { id: 5, content: '约好周末一起补看剧。', created_at: now - 30 * 3600_000 },
  { id: 6, content: '又说好周末一起补看剧。', created_at: now - 18 * 3600_000 }
];

test('memory review analyzer finds conflicts, preference change, unfinished promise', () => {
  const got = analyzeMemoryReviews(rows, now);
  assert.equal(got.length, 3);
  assert.ok(got.some(item => item.title.includes('金额')));
  assert.ok(got.some(item => item.title.includes('偏好')));
  assert.ok(got.some(item => item.title.includes('约定')));
  assert.ok(got.every(item => !Object.values(item).some(value => String(value).includes('欠款 160 文'))));
});

test('periodic memory review switch generates, deduplicates, and stops when disabled', () => {
  const dir=mkdtempSync(join(tmpdir(),'p223-periodic-')); const db=join(dir,'self.sqlite');
  try {
    const host=createSelfModelHost({dbPath:db, readSnapshot:()=>[]});
    assert.equal(host.memoryReviewStatus().enabled,false);
    assert.equal(host.tickMemoryReview(now,()=>rows),0);
    host.setMemoryReviewEnabled(true);
    assert.equal(host.tickMemoryReview(now,()=>rows),3);
    assert.equal(host.status().model.proposals.length,3);
    assert.equal(host.tickMemoryReview(now+10*60_000,()=>rows),0);
    assert.equal(host.status().model.proposals.length,3);
    host.setMemoryReviewEnabled(false);
    assert.equal(host.tickMemoryReview(now+20*60_000,()=>rows),0);
    assert.equal(host.status().model.proposals.length,3);
    host.close();
  } finally { rmSync(dir,{recursive:true,force:true}); }
});

test('insufficient evidence produces no proposal', () => {
  assert.deepEqual(analyzeMemoryReviews([{id:1,content:'今天天气不错。',created_at:now}],now),[]);
});

test('single memory repeated mentions do not count as two records', () => {
  const one = [{id:1,content:'欠款 160 文，后来又说欠款 175 文；我喜欢摄影也不喜欢摄影；约好周末补看剧，又说好周末补看剧。',created_at:now-30*3600_000}];
  assert.deepEqual(analyzeMemoryReviews(one,now),[]);
});

test('mixed owners are filtered before analysis', () => {
  const dir=mkdtempSync(join(tmpdir(),'p223-owner-mix-')); const db=join(dir,'self.sqlite');
  try {
    const host=createSelfModelHost({dbPath:db, readSnapshot:()=>[]});
    host.setMemoryReviewEnabled(true);
    const mixed=[
      {id:1,owner_id:'user:master',content:'欠款 160 文。',created_at:now-48*3600_000},
      {id:2,owner_id:'user:other',content:'欠款 175 文。',created_at:now-24*3600_000}
    ];
    assert.equal(host.tickMemoryReview(now,()=>mixed),0);
    assert.equal(host.status().model.proposals.length,0);
    host.close();
  } finally { rmSync(dir,{recursive:true,force:true}); }
});

test('unrelated completion does not suppress, matching completion does', () => {
  const base=[
    {id:1,content:'约好周末一起补看剧。',created_at:now-30*3600_000},
    {id:2,content:'又说好周末一起补看剧。',created_at:now-18*3600_000}
  ];
  assert.equal(analyzeMemoryReviews([...base,{id:3,content:'今天看完了别的电影。',created_at:now}],now).length,1);
  assert.deepEqual(analyzeMemoryReviews([...base,{id:4,content:'周末一起补看剧已经看完了。',created_at:now}],now),[]);
});

test('titles do not carry raw object or commitment fragments', () => {
  const got=analyzeMemoryReviews(rows,now);
  assert.ok(got.every(item => !item.title.includes('欠款') && !item.title.includes('摄影') && !item.title.includes('补看剧')));
  assert.ok(got.every(item => !item.title.includes('160') && !item.title.includes('175')));
});

test('different items with identical copy keep separate stable IDs', () => {
  const dir=mkdtempSync(join(tmpdir(),'p223-two-items-')); const db=join(dir,'self.sqlite');
  try {
    const store=new SelfModelStore(db);
    const copy={title:'金额记录不一致',finding:'同一事项出现 2 个不同的金额记录。',evidenceSummary:'摘要相同，但事项不同。',uncertainty:'不确定。',recommendation:'请确认。'};
    const a=store.submitMemoryReview({...copy,itemKey:'amount:first'},1000);
    const b=store.submitMemoryReview({...copy,itemKey:'amount:second'},1000);
    assert.notEqual(a.proposalId,b.proposalId); assert.equal(store.view().proposals.length,2);
    const again=store.submitMemoryReview({...copy,itemKey:'amount:first'},2000);
    assert.equal(again.proposalId,a.proposalId); assert.equal(store.view().proposals.length,2); store.close();
  } finally { rmSync(dir,{recursive:true,force:true}); }
});
