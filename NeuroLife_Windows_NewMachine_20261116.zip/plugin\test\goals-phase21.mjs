/**
 * Phase 2.1 验收测试：目标复盘 / 失败留痕 / 承诺同步 / 幂等 / 迁移回滚
 *
 * 全部在临时数据库上跑，不碰真库（openDatabase(path)）。
 * 运行：node test/goals-phase21.mjs
 */
import { mkdtempSync, copyFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const lib = new URL('../lib/', import.meta.url).href;
const { openDatabase, getKv, setKv } = await import(lib + 'db.js');
const g = await import(lib + 'goals.js');
const alive = await import(lib + 'alive.js');

const dir = mkdtempSync(join(tmpdir(), 'goals-phase21-'));
const db = openDatabase(join(dir, 'soul.db'));

let pass = 0;
let fail = 0;
function check(name, ok, detail = '') {
	if (ok) { pass++; console.log(`PASS  ${name}${detail ? '  — ' + detail : ''}`); }
	else { fail++; console.log(`FAIL  ${name}${detail ? '  — ' + detail : ''}`); }
}

const H = 3600_000;
const base = Date.UTC(2026, 10, 12, 4, 0, 0);

// ── 1. 正常推进 ──
const a = g.addGoal(db, { title: '把欠Rim的那张画完', why: '拖了好几天', now: base });
let captured = '';
const r1 = await g.advanceGoal({
	db, now: base + 7 * H, personaName: '祀',
	callLlm: async (p) => { captured = p; return '下一步：先只画线稿，不上色'; }
});
check('1 正常推进记一步', r1?.kind === 'step' && r1.text === '先只画线稿，不上色', JSON.stringify(r1));
check('1b 上次活动时间更新', Number(db.prepare('select last_step_at from goals where id=?').get(a.id).last_step_at) === base + 7 * H);

// ── 2. 失败写入 review ──
const f = g.recordFailure(db, a.id, { attempt: '上色', error: '颜色糊了', result: '重画', now: base + 8 * H });
const row2 = db.prepare('select * from goals where id=?').get(a.id);
check('2 失败计数与时间', f.failCount === 1 && Number(row2.last_fail_at) === base + 8 * H);
check('2b 失败摘要动态生成（review 不写）', /第 1 次没成/.test(g.failureSummary(db, a.id)) && row2.review === '', g.failureSummary(db, a.id));
check('2c 失败不改变状态', row2.status === 'active');
check('2d 失败有日志', g.goalEvents(db, a.id).some((e) => e.kind === 'failed'));

// ── 3. 下次提示带失败原因 ──
await g.advanceGoal({
	db, now: base + 15 * H, personaName: '祀',
	callLlm: async (p) => { captured = p; return '下一步：先定线稿再上色'; }
});
check('3 提示带上次失败', /失败记录/.test(captured) && /颜色糊了/.test(captured));
check('3b 提示要求换做法', /换一种做法/.test(captured));

// ── 4. 目标成功 → 关联承诺同步 ──
db.prepare('update goals set promise_id=? where id=?').run('pTEST1', a.id);
const changes = g.syncGoalsWithPromises(db, [{ id: 'pTEST1', status: 'done', what: '给你画一张' }], { now: base + 10 * H });
const row4 = db.prepare('select * from goals where id=?').get(a.id);
check('4 承诺完成 → 目标完成', row4.status === 'done' && changes.length === 1, JSON.stringify(changes));

// ── 5. 幂等：再同步一次不应重复关闭/写日志 ──
const again = g.syncGoalsWithPromises(db, [{ id: 'pTEST1', status: 'done' }], { now: base + 11 * H });
const doneEvents = g.goalEvents(db, a.id).filter((e) => e.kind === 'done').length;
check('5 重复同步无副作用', again.length === 0 && doneEvents === 1, `changes=${again.length} events=${doneEvents}`);

// ── 6. 目标放弃 → 承诺保留历史与原因 ──
const b = g.addGoal(db, { title: '练一下枯笔', promiseId: 'pTEST2', now: base });
const close = g.closeGoal(db, b.id, { why: '不想练了', dropped: true, now: base + 12 * H });
// 模拟承诺账：写入一条 open 承诺再按 ID 结掉
setKv(db, 'alive.promises', [{ id: 'pTEST2', what: '给你画一张枯笔', at: base, status: 'open', progress: '' }]);
alive.resolvePromise(db, 'pTEST2', 'dropped', '不想练了');
const list = getKv(db, 'alive.promises', []);
const pm = list.find((x) => x.id === 'pTEST2');
check('6 目标放弃记录原因', close.ok === true && db.prepare('select review from goals where id=?').get(b.id).review === '不想练了');
check('6b 承诺保留历史与原因', pm?.status === 'dropped' && pm?.note === '不想练了' && Array.isArray(pm?.history) && pm.history.length >= 1, JSON.stringify(pm));
const close2 = alive.resolvePromise(db, 'pTEST2', 'dropped', 'again');
check('6c 承诺结算幂等（不重复写历史）', close2 === true && (getKv(db, 'alive.promises', []).find((x) => x.id === 'pTEST2').history || []).length === 1);

// ── 7. 没有 promise_id 的目标不受影响 ──
const c = g.addGoal(db, { title: '想弄明白赭石怎么调', now: base });
g.syncGoalsWithPromises(db, [{ id: 'pOTHER', status: 'done' }, { id: 'pTEST3', status: 'dropped' }], { now: base + 13 * H });
check('7 无关联 ID 不被误关', db.prepare('select status from goals where id=?').get(c.id).status === 'active');

// ── 8. 模型建议放弃时，不自动 dropped ──
g.closeGoal(db, c.id, { why: '收工', now: base + 16 * H });
const d = g.addGoal(db, { title: '整理旧画稿', now: base });
g.closeGoal(db, b.id, { why: '已放弃', dropped: true, now: base + 16 * H });
const r8 = await g.advanceGoal({
	db, now: base + 20 * H, personaName: '祀',
	callLlm: async () => '放弃：实在没时间整理'
});
const row8 = db.prepare('select * from goals where id=?').get(d.id);
check('8 建议放弃不自动关闭', r8?.kind === 'wanted-to-drop' && row8.status === 'active');
check('8b 放弃想法写入事件（不改 review）', g.goalEvents(db, d.id).some((e) => e.kind === 'wanted-to-drop'), row8.review);
check('8c 放弃想法有日志', g.goalEvents(db, d.id).some((e) => e.kind === 'wanted-to-drop'));

// ── 9. 迁移幂等 + 回滚 ──
setKv(db, 'goals.ready.v22', false);
g.ensureGoals(db);
g.ensureGoals(db);
const cols = db.prepare('PRAGMA table_info(goals)').all().map((x) => x.name);
check('9 迁移幂等且列齐全', ['promise_id', 'last_fail_at', 'fail_count', 'failures'].every((x) => cols.includes(x)));
// 回滚方式：删事件表（列为附加列，保留不碍事），再次 ensureGoals 能重建
db.exec('DROP TABLE goal_events');
setKv(db, 'goals.ready.v22', false);
g.ensureGoals(db);
check('9b 回滚后重建事件表', db.prepare("select count(*) c from sqlite_master where name='goal_events'").get().c === 1);
check('9c 回滚后目标仍可读', g.listGoals(db, 'active').length >= 1);

console.log(`\n结果：通过 ${pass} / ${pass + fail}`);
db.close();
process.exit(fail === 0 ? 0 : 1);
